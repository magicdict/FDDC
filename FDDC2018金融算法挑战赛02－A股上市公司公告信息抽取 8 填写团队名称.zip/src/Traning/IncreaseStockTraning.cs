using System;
using System.Collections.Generic;
using System.Linq;
using FDDC;

public class IncreaseStockTraning
{

    /// <summary>
    /// 增发对象训练
    /// </summary>
    public static void TrainingIncreaseTarget()
    {
        var Target = new TableAnlayzeTool();
        TraningDataset.InitIncreaseStock();
        var PreviewId = String.Empty;
        var PreviewRoot = new HTMLEngine.MyRootHtmlNode();
        foreach (var increase in TraningDataset.IncreaseStockList)
        {
            if (!PreviewId.Equals(increase.id))
            {
                var htmlfile = Program.DocBase + @"\FDDC_announcements_round1_train_20180518\定增\html\" + increase.id + ".html";
                PreviewRoot = new HTMLEngine().Anlayze(htmlfile, "");
                PreviewId = increase.id;
            }
            Target.PutTrainingItem(PreviewRoot, increase.PublishTarget);
        }
        Target.WriteTop(10);
    }
}