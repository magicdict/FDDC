import os
os.system("dotnet run")
